<!-- GENERICIZATION NOTE: genericized from origin FOUNDATION.md; §1.3 (halt-loud) and §8.2 (no-fake-closures) preserved verbatim as generic binding text; all project-specific rationale, site names, gate sequences, compliance figures, compliance regimes, architecture specifics, and instance-ISSUE references stripped and replaced with generic stubs. Origin pin: a0929259. Boot-creed trigger→cite convention added per architect relay XP-07 + work-item F, genericized from origin fix ff92e836 (wiring only; cites existing disciplines entries). -->
<!-- skeleton -->
# FOUNDATION.md — {{PROJECT_NAME}} engine reference

**Status:** consolidated single-file reference for project rationale, invariants, operating
discipline, and architecture. The engine canonical source; all live canonical docs in-repo win
on conflict.

**Authority hierarchy — this document defers to (all live, in-repo):**

| Domain | Canonical doc |
|---|---|
| Pipeline architecture / gate contract | `docs/SPEC-PIPELINE.md` *(adopter fills)* |
| Operating discipline / agent roles | `_knowledge/COORDINATION.md` · `CLAUDE.md` |
| Build sequencing | `CHECKLIST.md` |
| Issue / decision record | `issues_register.md` |
| Contract surface | `contracts/` *(adopter fills)* |

Where this document and a live canonical doc disagree, **the canonical doc wins** and this file
should be corrected.

---

## 0. How to use this document

This file is the **stable orientation layer** so intent, rules, and standards do not have to be
re-explained each session. It is not a substitute for the live canonical docs.

---

## PART I — PROJECT RATIONALE (adopter stub)

> **Adopter instructions:** replace this section with the specific project's rationale — why the
> pipeline exists, what failure mode it was built to prevent, and what the operation is trying to
> accomplish. Be specific; generic rationale is invisible in practice.

### 1.1 The operation

*(Describe: what the project produces, who it serves, what platforms/systems are involved.)*

### 1.2 The failure that motivated the build

*(Describe: what went wrong without this pipeline, or what the system is designed to prevent.
Concrete failure metrics are more useful than abstract risks.)*

### 1.3 The core principle that resulted

> **The pipeline must stop rather than produce partial or fabricated output.**

Every downstream choice — the gate sequence, the human approval gate, the live-data-only rule,
the "no fake closures" discipline — is a structural answer to a specific line in the failure
history. **This principle is binding and generic: it applies to every adopter.**

---

## PART II — VISION & TRAJECTORY (adopter stub)

> **Adopter instructions:** describe the phased plan (e.g. Phase 1 = survive/remediate, Phase 2 =
> operate at measured pace, Phase 3 = accelerate). Name what gates each phase requires, and what
> is explicitly deferred to later phases.

---

## PART III — PIPELINE ARCHITECTURE (adopter stub)

> **Adopter instructions:** describe the gate sequence, the two-tier substrate design (research
> tier → production/publishing tier), and the cross-cutting rules (evidence-not-intuition, current-
> not-cached, halt-on-missing-evidence, per-item isolation, separation of research from writing).

### Gate sequence (template — adopter fills)

| Gate | Purpose | Prevents |
|---|---|---|
| *(gate-G1 stub)* | *(purpose)* | *(failure mode)* |
| *(…)* | | |

---

## PART IV — COMPLIANCE FRAMEWORK (adopter stub)

> **Adopter instructions:** enumerate the regulatory / platform regimes that apply to this
> operation. Each regime can end the business independently; treat them co-equally. Include
> re-verification rule: "platform/regulatory facts must be re-verified against current live
> documentation before being relied on — treat figures in this doc as 'as of compile date'."

---

## PART V — OPERATING DISCIPLINE (binding — not a stub)

### §5.1 Foundational invariants

**Two-tier architecture.** Research outputs land in a research/staging tier first — never directly
in the publishing/production tier. A human approval gate promotes approved items. Rejecting a
candidate rejects a staged row (safe) rather than deleting from a live pipeline (risky).

**LIVE-DATA-ONLY.** All end-to-end validation must traverse the canonical pipeline path. Hand-
INSERT smoke-bypass paths are prohibited regardless of cleanup discipline — fabricated data that
satisfies schema constraints reproduces the original failure pattern in miniature.

**Sproc/mechanism-only writes.** The workload application user has INSERT/UPDATE/DELETE = 0 on
substrate tables BY DESIGN. Every write goes through a sanctioned mechanism (stored procedure,
sanctioned API call) + execute grant. The instinct to "grant INSERT for convenience" is the anti-
pattern; treat as a contract violation.

### §5.2 Cross-cutting rules

| Rule | Statement |
|---|---|
| **Evidence, not intuition** | Every fact carries source: URL + fetch timestamp. Facts without source are invalid; the mechanism halts. |
| **Current, not cached** | Facts come from fetches in *this* run. Training knowledge and stale rows are not valid sources. |
| **Halt on missing evidence** | Missing required output → mechanism halts. No best-effort advancement. |
| **Per-item isolation** | Mechanisms run per item, not per batch. If A passes and B fails, A advances and B halts independently. |
| **Separation of research from writing** | Research mechanisms produce sourced facts. Content generation consumes them and is forbidden from inventing facts. |
| **Live-documentation verification** | Platform/tool facts verified against current live docs, not training knowledge. |

---

## §8 — Discipline rules (binding — not a stub)

### §8.1 Halt-loud over silent-degradation

On `stop_reason ∈ {refusal, max_tokens}`, missing required env var, or an unverifiable load-
bearing claim: **HALT with a named reason.** No lexical/regex fallback, no silent default, no
degraded continuation. Every mechanism that can halt must emit a named halt code with a human-
readable reason before stopping.

This is the structural answer to the failure pattern where pipelines silently produced degraded
output (hallucinated data, fabricated citations, skeleton content) because no mechanism stopped
them. **Stop rather than fabricate** is the invariant.

### §8.2 No fake closures

**Issue status is a hypothesis.** A closure is only valid when:

1. The fix is committed at a specific SHA (cite it).
2. A re-runnable probe or verification step confirms the behavior is corrected in the live system.
3. The issue register entry carries that evidence chain.

Closing an issue because "the fix was applied" without a re-runnable verification artifact is a
fake closure. It reproduces exactly the failure mode that motivates this rule: the "LIVE per file"
claim that has no probe backing it.

**RETRACT** on a refuted premise (do not "close" with a wrong explanation). Close only on grep'd
closeout evidence + probe evidence. Delta lines machine-derived from `git diff`, never hand-counted.

---

## Boot-creed trigger→cite convention

A triggered conclusion carries an INLINE citation of the pulled `disciplines.md` entry; an un-cited
triggered conclusion is refused at the receiving seat.

| Triggered conclusion | Cite inline |
|---|---|
| absence / "not found" / "no record" | DISC-ABSENCE-OF-RECORD |
| done / pass / resolved / closed | no-fake-closures (§8.2 above) |
| an inherited count into a ruling | DISC-NO-INHERITED-COUNT |
| a fact about live state (a row / artifact / another seat's output) | DISC-VERIFY-BEFORE-RULING + readback |

---

## PART VI — REFERENCE (adopter stub)

> **Adopter instructions:** list the live canonical docs, their paths, and what domain each governs.
> This section is the first place a new session or agent looks to orient itself.

*(Fill: spec file, contracts, coordination doc, disciplines doc, CHECKLIST, issues_register.)*
