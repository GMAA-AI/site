# SPEC-DOORBELL v0.3 — event-driven wake-and-dispatch (tmux = BELL, git inbox = TRANSPORT)

# GENERICIZATION NOTE: Stripped — dates, ruling-ids (replaced with "rule-stated"), real instance
# lane names (replaced with {{MODULE_LANE}}), executor-seat name (applied rename map §2),
# architect-seat label (applied rename map §2), integrator-seat label (applied rename map §2).
# Correction-of-record in §0 kept (mechanism explanation).
# §3 PREFLIGHT stripped to shape (real path + named sessions were instance-specific).
# §4 OPERATOR CUSTODY stripped to obligation shape. All mechanism invariants kept verbatim.

**Target:** `contracts/SPEC-DOORBELL.md` (governance-class; architect authors, operator binds, foundation merges).
**Version:** v0.3 — **SUPERSEDES v0.2**. Adds the BINDING producer-ring obligation (Ruling 1), the auto-fire-on-inbox-commit backstop (Ruling 2), and the remote-control-active policy (Ruling 3). Architect-ratified (relay → architect ruling); foundation codified + RUN-proved.
**Authority:** architect. §2 wrapper-contract shape + §7/§8/§9 rulings = `[ARCHITECT RATIFICATION]`; codify+wire+RUN-prove = foundation (§5).
**Status:** v0.3 RATIFIED + RUN-PROVEN (L1–L5). v0.2 §6 (L1/L2) carried; L3/L4/L5 added + proven this arc.

---

## §0 — CORRECTION OF RECORD (why v0.3)

v0.2 §1 called the doorbell an "OPTIONAL notify layer." That wording (architect-owned) conflated **LAYER-optionality** (the channel is architecturally correct + lossless WITHOUT the bell — the durable git inbox is the transport) with **RING-discretion** (the producer choosing whether to ring). The second reading is WRONG and it licensed a live omission: foundation committed an actionable unblock to a lane's inbox and did NOT ring it → the lane sat idle, unaware. v0.3 closes the ambiguity: **ringing an idle lane that has an actionable payload is OBLIGATORY**; optionality is a property of the layer's existence + its drop-robustness, never permission to skip.

## §1 — LAYERING (binding; v0.2 carried)

- **TRANSPORT** = the durable git inbox: `scripts/inbox.sh` over `_orchestration/relay-inbox/<lane>/`.
- **DOORBELL** = the wake layer: it causes the target lane to take a turn so its first-action INBOX-CHECK fires now, rather than at its next operator-spawned turn.
- **A dropped bell DELAYS, never LOSES** (§23 safety property): payload lives in git; next turn still catches it. This is the backstop for GENUINE drops (lane not in tmux / dead session / raced send) — **NOT** license to skip a needed ring (see §7).

## §2 — WRAPPER CONTRACT (foundation builds; `scripts/doorbell.sh`)

- **(R1) ROLE→PANE resolution:** resolve by **session_name** (Claude Code overwrites `pane_title`, so v0.2's pane-title assumption was refined): `list-panes -a` → exactly-one `session_name==<lane>` → else HALT-LOUD.
- **(R2) TWO-PHASE send:** `send-keys -l '<wake-string>'` THEN `send-keys Enter` as a separate call (chaining swallows the submit); + submit-verify (pane cksum change / Claude busy-indicator) + Double-Enter fallback.
- **(R3) FAIL-LOUD (interactive path):** unresolved/ambiguous target → non-zero exit + NAMED reason. NEVER exit 0 silently. NEVER broadcast on a bare session name.
- **(R4) ACK-REQUIRED:** the bell is "done" ONLY when the target's outbox consume-ack lands. No ack in window → HALT-LOUD.
- **(R5)** the wake-string is a FIXED token (the literal the orc parses as its INBOX-CHECK trigger), NOT the payload.

## §3 — PREFLIGHT (foundation attested at build time)

P1 tmux installed: confirm at build time. P2 lanes as named sessions: each active lane must run as a named tmux session (session-name == lane) — operator relaunch responsibility. P3 v0.1 transport refutation: send-keys-as-transport silently drops (exit 0, no delivery, no log) = halt-loud violation → tmux is the BELL, never the transport.

## §4 — OPERATOR CUSTODY

Relaunch lanes as named tmux sessions (orc cannot relaunch the session it runs inside). All active lanes must be named + attached before the bell mechanism is relied on.

## §5 — OWNERS

Codify + wire + fire + RUN-prove: foundation (sole committer + autonomous executor). Architect ratifies the contract shape + §7/§8/§9 rulings; does not commit.

---

## §7 — PRODUCER-RING OBLIGATION (Ruling 1; BINDING — rule-stated)

**Codified in BOTH `.claude/agents/orc.md` ROUTING and here.** Binding wording:

> "On committing to `relay-inbox/<lane>/` a payload that requires the target orc to act, ringing that lane's doorbell is part of **COMPLETING** the output — not a discretionary follow-up. The ring completes the output; the R4 consume-ack closes it. A committed-but-unrung actionable notify-output is an **INCOMPLETE** output, same class as a payload written but never committed.
> **DEFAULT TO RING:** if it is unclear whether a payload requires action, RING. A redundant wake is a cheap no-op turn (INBOX-CHECK idempotent, flat-rate on the model plan); a missed wake strands the lane and needs a human. The only non-ring cases are (a) payloads definitionally informational — no expected response, correctly served by the lane's next natural turn — and (b) lanes the ring genuinely cannot reach (not in tmux / session absent), handled by the §1/§23 safety property and SURFACED, never silently skipped."

**§22 QUALIFICATION (bind this exact distinction):**

> "The doorbell LAYER is architecturally optional — the durable git inbox is correct and lossless without it. That is the §23 'delays never loses' SAFETY property: the backstop for GENUINE drops (lane not in tmux, dead session, raced send). It is NOT license to skip a needed ring. When the layer is live and a lane is idle awaiting an actionable payload, the ring is OBLIGATORY per Ruling 1. Optionality is a property of the layer's existence and its drop-robustness — never permission to choose not to ring."

## §8 — AUTO-FIRE-ON-INBOX-COMMIT BACKSTOP (Ruling 2; RATIFIED — rule-stated)

`agents/post-commit-hook.sh` §(1c), foundation-branch only: parse the commit's changed paths → for every `relay-inbox/<lane>/` touched, ring that lane; **dedupe per-lane-per-commit**; rings on **ALL** inbox writes (the hook does NOT judge "requires action" — redundant wakes are the safe direction, dissolving that judgment). Binding refinements — the auto-hook differs from the interactive ring:

- **NON-BLOCKING:** the hook MUST NOT block or fail the commit (the commit already landed; a blocking post-commit hook is itself a defect). Best-effort ring only (`set +e` subshell + `|| true`).
- **SURFACE-UNRUNG, NEVER SILENT:** a lane that can't resolve to a live pane (not in tmux / session absent / ambiguous) → record `unrung: <lane> (<reason>) <sha> <ts>` to `ledger/doorbell.log` (the VISIBLE surface). This IS the §23 safety property operating: payload durable in git, lane catches it via obligatory INBOX-CHECK on its next reachable turn; the unrung notice makes the deferred delivery visible.
- **R3 fail-loud CONTINUES to govern the INTERACTIVE/manual ring** (`doorbell.sh ring <lane>`), where a bad target is an operator-visible error to fix — not a deferred delivery. **Two paths, two failure modes.**

Net: **Ruling 1 is the human-readable DISCIPLINE; Ruling 2 is the judgment-free ENFORCEMENT** for foundation's commits. Together the producer never decides whether to ring. (Same discipline+backstop pattern as the INBOX-CHECK invariant.)

## §9 — REMOTE-CONTROL-ACTIVE POLICY (Ruling 3; RULED (b) suppress-and-surface — rule-stated)

- **"Remote-control-active" is an EXPLICIT set state** — foundation's primitive = a session-scoped tmux user-option `@remote_control` (set when a driver takes manual control of a lane; unset on release). **MERE CLIENT-ATTACHMENT DOES NOT QUALIFY** — an attached-but-idle lane still needs its ring (suppressing on attachment would reintroduce the exact stranding this fix removes).
- **When the marker is SET:** suppress the auto-ring + surface `unrung: <lane> (remote-control-active)`.
- **Rationale:** a lane under active manual control is already awake + taking turns, so its obligatory INBOX-CHECK delivers on its next turn with no ring needed; the ring would only risk racing the driver's live input line.
- **For the record:** the reference incident was IDLE, not remote-control-active. The remote-control caveat did not hold — idle is never remote-control-active. This narrow definition BARS that rationalization: **idle is never remote-control-active.**

---

## §6 — ACCEPTANCE (no-fake-closure; proven only by a real RUN)

- **L1 (carry, positive interactive):** `doorbell.sh ring <live-lane>` → wake lands → (lane) INBOX-CHECK → consume-ack.
- **L2 (carry, fail-loud interactive):** a DELIBERATELY-BAD target → non-zero exit + named reason (NOT silent exit 0).
- **L3 (new, auto-fire):** a foundation commit touching `relay-inbox/<lane>/` auto-rings that lane (event-driven); per-lane dedupe holds (two files under one lane → one ring).
- **L4 (new, unrung surfaced):** an unreachable lane on auto-fire → `unrung: <lane> (<reason>)` recorded to `ledger/doorbell.log`; the commit is NOT blocked.
- **L5 (new, remote-control):** `@remote_control` set on a lane → auto-ring SUPPRESSED + `unrung: <lane> (remote-control-active)` surfaced.

Stored blueprint ≠ proof. Acceptance via real RUN (decision-log entry: L1–L5 evidence).

**Sibling (note, not scoped here):** doorbell-lifecycle dead-session detection carries to the reaper §4A session-pid gap.
