# OPERATING-DISCIPLINE — Completion, Verification, State Persistence (v1.0)

# GENERICIZATION NOTE: Heavily adapted from an origin discipline contract.
# Stripped: all instance-specific verification commands (build paths, test-runner paths,
# probe names tied to the origin domain), real function-app and workload-SP names (replaced
# with {{FUNCTION_APP}} / {{DB_APP_USER}} slots), real ISSUE citations (replaced with "rule-stated"),
# specific Code-App paths (replaced with generic slot descriptions), project name ({{PROJECT_NAME}}),
# architect-seat / executor-seat labels (§2 rename map applied), dated standing-retractions
# section (operating record — stripped entirely).
# Mechanism kept: Completion Contract shape, Verification Gate pattern, State Persistence
# read-order + write-obligations, binding-to-invariants frame. All five invariant bindings kept.

> **Framing principle (throughline).** Every claim of progress must reduce to
> something a command can confirm — a test, a build, a running endpoint. The
> goal and the state must live in files Claude reloads, not in a context window
> it loses. Give the work that scaffold and it drives to completion; withhold it
> and no amount of prompting "be disciplined" will hold.

These sections sit alongside the Binding Invariants already declared in
`CLAUDE.md §Binding invariants`. They are the *enforcement* layer for two invariants
already on that list — **inv.4 No fake closures** and **inv.5 Halt-loud over
silent-degradation** — converting stated intent into mechanisms Claude and orc
cannot talk past.

This applies equally to architect, orc, code-Auditor, and any cowork surface. No agent
is exempt.

---

## Completion Contract — what "done" means

A task is complete only when a named verification command exits `0` and its
output appears in the response. The words *done*, *working*, *fixed*,
*passing*, *complete*, *shipped*, or *closed* are prohibited unless immediately
accompanied by the command run and its exit status. A natural-language
assertion of success with no command behind it is a fake closure and is void.

**Verification command table (adopter-filled — bind the project's actual commands):**

| Class | Command | Pass condition |
|-------|---------|----------------|
| Build / typecheck | `<adopter: fill with project build command>` | exit 0, clean output |
| Unit tests | `<adopter: fill with test runner command>` | exit 0, N passed |
| Smokes | `<adopter: fill with smoke runner command>` | exit 0, N passed |
| Standing probes | `<adopter: fill from standing-probes.yaml registry>` | exit 0, `VERDICT: PASS` |
| Mechanism apply (C-DB SLOT) | `scripts/run_sql.sh <migration-path> --emit-receipt --auth=<privileged>` | receipt path emitted; receipt appended to `ledger/receipts.jsonl`; tool `-b` flag surfaces THROW errors as nonzero exit |
| Issue closure | Evidence enumerated in `issues_register.md` entry; body cites receipt id / commit sha / test reference | enumerated, not asserted |
| Post-commit auditor | Runs automatically via git post-commit hook; emits receipt to `ledger/receipts.jsonl` | Auditor receipt VERDICT: PASS / REPRODUCED |

**C-GATE SLOT:** if the project wires a gate executor (function-app or equivalent), add a row:
gate smoke / gate live-fire / deployment verification — per the project's gate contract.

If a claim cannot be reduced to one of the above (or the adopter-filled equivalent), it is not a completion. It is a hypothesis and must be labeled as such. Reporting an unverified change as finished is the single most expensive failure mode and is treated as a discipline breach, not an honest mistake.

---

## Verification Gate — Stop hook

A Stop hook runs the verification suite after every response and blocks the
session from reporting completion until the suite is green. Deterministic hook
checks are preferred over prompt-based self-checks because the model cannot
reason its way past a non-zero exit code.

- **Location:** `.claude/hooks/verify.sh`, wired as a Stop hook in the Claude
  Code configuration.
- **Behavior:** runs the build, then the unit test suite, then the smoke suite,
  in that order. On any non-zero exit, the hook surfaces the failing command
  and its output, and the session must *continue working*, not conclude.
- **Authority:** the hook is the gate; the model's self-assessment is not.

This complements the existing post-commit code-Auditor (separate Claude Code
session, audit-only system prompt, auto-triggered via git post-commit hook). The
post-commit auditor audits what has already landed in git. The Stop hook gates
what the active session is permitted to call finished. The two are not redundant — one guards the commit, the other guards the claim.

**C-DB SLOT gate:** any session that touches mechanism-layer paths (migrations, sprocs, schemas) must run the `insert-zero` standing probe before concluding. This enforces the WRITE-VIA-MECHANISM invariant at the session level, not only at the post-commit auditor level.

---

## State Persistence — survive context compaction

Context windows are lost; disk is not. Anything that must outlive the current
window lives in files, and those files are read at the start of every session
before any action is taken.

**Session-start read order (mandatory, before the first edit or directive):**

1. `CLAUDE.md` — operating contract
2. `CHECKLIST.md` — status rollup index (the DAG+WP system: `dag/DAG.yaml` WP graph + `work-packages/` contracts are the system of record; CHECKLIST.md rolls them up); what ships next
3. `issues_register.md` — open issues; no settled decision is re-raised
4. `contracts/*_AMENDMENT_*.md` — all amendments dated after the most recent
   base spec; amendments supersede base specs
5. `plans/` — the latest timestamped plan for the active task
6. `session_logs/` — the latest log, for reasoning that predates this window
7. `SESSION_HANDOFF_*.md` (if operator-couriered for the session) —
   authoritative for session state, team structure, and operating mode

**Write obligations during work:**

- `plans/` — every non-trivial task gets a timestamped plan, written and
  approved *before* execution begins. Plans persist on disk; they survive
  auto-compaction and session boundaries intact.
- `session_logs/` — reasoning is logged at three points: immediately after
  plan approval, incrementally as decisions are made, and at session end.
  The log captures the *why* that git commits omit.
- `issues_register.md` — every architect-class observation, named risk, or
  discipline finding lands here, not in chat. Per the hub-and-spoke routing rule,
  architect proposes ISSUE bodies; foundation commits.

**Rule.** If it is not in `CHECKLIST.md`, `issues_register.md`, a `contracts/`
amendment, a plan, or a session log, it does not persist and must not be
assumed across sessions.

This rule is load-bearing. It retroactively voids any architectural claim
made in chat that did not land in a canonical file. The agent that made the
claim does not get to carry it across sessions through memory or inference.
Either it commits, or it dies with the window.

---

## Binding to existing invariants

- **inv.4 No fake closures** is enforced by the Completion Contract (no
  success word without a command and its exit code) and the Stop hook (no
  concluding on a red suite). Together they make fake closure a hook
  violation, not a discretionary breach.
- **inv.5 Halt-loud over silent-degradation** is enforced by the read-order
  ritual: a missing plan, a stale log, or an unread contract amendment is
  surfaced at session start, not papered over. It also extends to
  verification commands themselves — a probe that returns `RUN_ERROR` is
  surfaced and emitted; it is not retried until silent or attributed to
  "transient."
- **inv.1 LIVE-DATA-ONLY** is reinforced by the verification table — every
  pass condition is a real command against the real system, never a
  described one. No "the test would pass," no "the build should succeed,"
  no "I would have run the smoke." Run it or do not claim it.
- **inv.2 WRITE-VIA-MECHANISM** is enforced by the existing `insert-zero`
  standing probe (C-DB SLOT) and by the Stop hook's mechanism-layer session
  gate above.
- **inv.3 MECHANISM-CONTRACT** is enforced at substrate-amendment time by
  the post-commit code-Auditor checking canonical call-shape presence for
  every new mechanism entry; the Stop hook does not add a layer here.

---

## Standing retractions — general pattern

Per the State Persistence rule above, any architectural claim authored in chat does **not** persist into canonical state until it lands in `CLAUDE.md`, `issues_register.md`, a contract amendment, a plan, or a session log via proper commit.

Claims that are surfaced honestly rather than papered over — describing failure-mode patterns worth ratifying — should be routed through proper amendment. The retraction is a discipline statement, not a substantive rejection. The operator may direct foundation to commit any such claim through the proper channel; until then, they are draft observations, not binding rules.
