#!/usr/bin/env bash
# F4 RUNNABLE NEUTRAL REF-IMPL — fire_ref.sh
#
# PURPOSE: Demonstrates the {{EXECUTE_MECHANISM}} slot in action.
#   Fires a gate-execution request to a generic HTTP endpoint.
#   On --dry-run: prints the request and exits 0 with NO network calls.
#   On live: POSTs to GMAA_EXECUTE_URL (must be set in env).
#
# This script is the low-disclosure, no-adopter-infra proof that the
# free engine is RUNNABLE. It contains no real ids, credentials, domains,
# or service bindings. Wire {{EXECUTE_MECHANISM}} to your own endpoint
# by setting GMAA_EXECUTE_URL in your environment.
#
# Usage:
#   bash fire_ref.sh --dry-run           # prints request, exits 0, no network
#   GMAA_EXECUTE_URL=http://localhost:8080/gate bash fire_ref.sh  # live POST
#
# Env slots (adopter fills):
#   GMAA_EXECUTE_URL   — the mechanism endpoint URL
#                        (default: http://localhost:8080/gate for dry-run)
#   GMAA_GATE_ID       — which gate to fire (default: G7)
#   GMAA_ITEM_ID       — the item identifier (default: ITEM-REF-001)

set -euo pipefail

GATE_ID="${GMAA_GATE_ID:-G7}"
ITEM_ID="${GMAA_ITEM_ID:-ITEM-REF-001}"
EXECUTE_URL="${GMAA_EXECUTE_URL:-http://localhost:8080/gate}"
DRY_RUN=false

for arg in "$@"; do
  case "$arg" in
    --dry-run) DRY_RUN=true ;;
    *) echo "Unknown argument: $arg" >&2; exit 1 ;;
  esac
done

PAYLOAD=$(printf '{"gate":"%s","item_id":"%s","run_id":"%s"}' \
  "$GATE_ID" "$ITEM_ID" "RUN-$(date -u +%Y%m%dT%H%M%SZ 2>/dev/null || echo 'RUN-REF')")

if [ "$DRY_RUN" = "true" ]; then
  echo "[fire_ref.sh --dry-run] NO network call made."
  echo "  execute_url : $EXECUTE_URL"
  echo "  gate        : $GATE_ID"
  echo "  item_id     : $ITEM_ID"
  echo "  payload     : $PAYLOAD"
  echo "[fire_ref.sh] exit 0 (dry-run)"
  exit 0
fi

if [ -z "${GMAA_EXECUTE_URL:-}" ]; then
  echo "ERROR: GMAA_EXECUTE_URL is not set. Set it or use --dry-run." >&2
  exit 1
fi

echo "[fire_ref.sh] POSTing to $EXECUTE_URL"
curl -sf -X POST "$EXECUTE_URL" \
  -H "Content-Type: application/json" \
  -d "$PAYLOAD"
echo ""
echo "[fire_ref.sh] exit 0"
