# C-RATIFICATION-PACKET — Set-Level Authorization Mechanism (v1.0)

# GENERICIZATION NOTE: Minimal strip applied — the origin source was already largely generic.
# Stripped: real author identity label (§2 rename map applied), real date (replaced with rule-stated),
# integrator-seat short label (§2 rename map applied to "foundation"),
# thesis-internal journey/finding citations (replaced with "rule-stated" + neutral framing).
# All mechanism invariants, schema, taxonomy, and acceptance criteria kept verbatim.

AUTHOR: architect
STATUS: authored on ack (F1 split: architect contract → foundation builds mechanism)
PLACE AT: `contracts/C-RATIFICATION-PACKET.md` (+ `_knowledge/` symlink) · extract to `_rulings/` per rule-stated
BASIS: architect relay ruling (verbatim; this page is the schema rendering, no semantic additions) · coherence-law taxonomy · SPEC-COHERENCE at HEAD in `contracts/`

---

## §1 — Object and gate

`_ratification/SET-NNNN.md` on the SPINE. Foundation assembles at wave close; module lanes contribute member entries via their own branches and NEVER write the packet. **MERGE GATE:** no member branch merges to main until its set's packet carries a decision line of RATIFIED or RATIFIED-WITH-SEQUENCE (then in stated order). Per-WP Ring-2 + auditor unchanged — the COMMIT unit is what changes. Composes with the state machine: merge stays VERIFIED→CLOSED; merge AUTHORIZATION becomes set-scoped.

## §2 — Packet schema (one file per set)

```
SET-NNNN
├─ HEADER: set id · wave id · assembled-by (foundation) · assembled-at (UTC) · HEAD sha at assembly
├─ MEMBERS (one block per pending change):
│    wp_id · lane · branch@sha · one-line intent · receipts (paths) ·
│    cross-lane touchpoints · shared-substrate objects touched
├─ CONFLICT SWEEP: subagent sweep of live docs + codebase across the joint set —
│    findings listed with evidence paths; "none found" is a claim requiring the sweep receipt
├─ COHERENCE CHECKS: each set-level check run · result · evidence path
│    (set-level = evaluable only on the JOINT set; a check any member passes alone doesn't belong here)
├─ BRIEFING: grounded alternatives for any member the assembler flags as contestable
├─ DECISION LINE (operator, exactly one; §3 taxonomy) + rationale + RATIONALE CLASS (§4)
└─ POST-DECISION: merge order executed (if -WITH-SEQUENCE) · auditor reproduction ref
```

## §3 — Decision taxonomy (rule-stated; closed set; never a bare no)

| Line | Effect |
|---|---|
| `RATIFIED` | foundation merges the set |
| `RATIFIED-WITH-SEQUENCE` | merges in the stated order, no other change |
| `AMENDED` | per-member dispositions; **SUBSET RULE applies (§5)** |
| `HELD` | set → PARKED against a NAMED trigger (event/date recorded); re-surfaces on trigger; never limbo |
| `REJECTED` | per-member dispositions + rationale + the briefing's grounded alternatives |

State-machine additions (schema/state-machine.md, ruled): VERIFIED→RETURNED (branch PRESERVED; WP reopened carrying rationale + alternatives; relayed to proposing lane's inbox via doorbell) · VERIFIED→PARKED · RETURNED→IN_PROGRESS or ABANDONED (reaper-archived per SPEC-REAPER, never deleted).

## §4 — Rationale class (recorded on ALL outcomes)

`in-band` (resolvable from system-of-record facts) vs `OUT-OF-BAND` (deciding fact lives outside the store — cutover, hold, strategy, commitment). Recorded on ratifications AND rejections — out-of-band decisions in either direction are thesis obligation evidence. The packet is the collection instrument; tallies feed the coherence proof.

## §5 — Binding invariants

- **SUBSET RULE:** an AMENDED set is a NEW set. Retained members re-enter packet assembly + JOINT re-validation before any merge — removing a member can change joint coherence. Line-item ratification does not exist. Anything weaker reintroduces per-change authorization through the side door and falsifies the thesis in its own reference implementation.
- **NO-CHERRY-PICK (D3-enforced):** RETURNED content reaches main ONLY inside a future ratified set. Cherry-picking a returned branch = boundary bypass = discipline violation.
- **LOOP GUARD:** same set RETURNED twice → automatic architect escalation (repeat rejection usually signals contract ambiguity, not defective work).
- **INDEPENDENCE:** the assembler validates; the operator ratifies; the auditor reproduces post-merge. No seat holds two of those three roles for the same set.

## §6 — Acceptance

Mechanism proven only via worked journeys (post SPEC-COHERENCE ratification): a seeded joint incoherence CAUGHT at assembly, demonstrably NOT catchable per-member, one non-RATIFIED walk exercising the RETURNED machinery, receipts per the coherence proof acceptance criteria. Firewall in force: this contract existing ≠ thesis proven; never claim proven-complete.
