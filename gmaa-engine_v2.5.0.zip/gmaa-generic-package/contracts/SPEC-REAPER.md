# SPEC-REAPER v0.2 — worktree-lifecycle reaper (worktree GC mechanism)

# GENERICIZATION NOTE: Stripped — dates, ruling-ids and ARCH-refs (replaced with "rule-stated"),
# executor-seat / architect-seat / integrator-seat labels (§2 rename map applied),
# instance lane name (replaced with {{MODULE_LANE}}), real SHAs (replaced with <sha>).
# All mechanism invariants, binding rules, and AC criteria kept verbatim.

**Target:** `contracts/SPEC-REAPER.md` (governance-class; architect authors, operator binds, foundation merges). Impl lands on foundation/main code-track per §6.
**Delivery of this artifact:** operator-paste. No spine inbox `Target:` claimed.
**Version:** v0.2 DRAFT. v0.2 folds in the §7 readback result: adds the owner-pid stamp at worktree-create (§4A) that §4.2's PID gate requires, since no owner/PID source exists today.
**Authority:** architect `[ARCHITECT RATIFICATION]` for the mechanism shape and the build-it-don't-override ruling. Resolves the worktree-accumulation gate (rule-stated). Companion to the governance-topology amendment and the GOVERNANCE-CHECK Phase-2 (`governance.sh`).
**Status:** SHAPE RATIFIED; §7 readback ANSWERED (see §7). Build unblocked; foundation builds as integration fill.

---

## §0 — Ruling: build the reaper, do not override the gate [ARCHITECT RATIFICATION]

The seat worktrees and `governance.sh` are both gated behind this mechanism. The alternative — override the gate and `git worktree add` now — knowingly re-creates the orphan-worktree incident the gate exists to prevent (worktrees/branches accumulating until `git worktree add` fails under concurrent commits). There is no priority pressure that justifies accepting a known failure on non-critical work to save minutes. **Ruling: build the reaper first; worktrees and `governance.sh` follow once it lands.** This is a HOW-class call; it is not routed to the operator.

## §1 — Problem (what the reaper closes)

A worktree is meant to be transient: a lane authors in it, foundation merges the branch, the worktree's purpose ends. Without a lifecycle closer, merged worktrees and their branches **linger and accumulate**. Symptoms, in order of severity:
- Stale `.git/worktrees/<name>/` administrative entries and lock files block `git worktree add` from re-using a name.
- Index/HEAD locks left by crashed or abandoned sessions block operations on re-create.
- At volume (the incident: ~31 orphan worktrees) concurrent commits collide with the lingering admin state and `git worktree add` fails outright.

The reaper is the teardown counterpart to `git worktree add`. It runs at the two moments accumulation happens: **at merge** (normal path) and **on stale-lock detection** (abandoned path).

## §2 — Binding invariants (load-bearing; violation = HALT)

1. **NO SILENT DATA LOSS (force-remove guard).** A worktree carrying uncommitted changes OR detached/unmerged commits MUST NEVER be auto-force-removed. Detect dirt and unmerged state FIRST; if either is present → **HALT and surface to operator**, never `git worktree remove --force`. This is halt-loud-over-silent-degradation applied to teardown. (Binding guard, restated.)
2. **PID-GATED, NOT AGE-GATED, for locks.** A stale lock is reaped only when its owning process is confirmed DEAD (PID check). Age-only reaping deletes a worktree that is merely slow/quiescent. Age MAY be a secondary signal, never the sole one.
3. **REAP ONLY MERGED+CLEAN on the normal path.** Reap-at-merge fires only for a branch confirmed merged into main AND a worktree confirmed clean. Merged-but-dirty → HALT (invariant 1).
4. **FOUNDATION-ONLY EXECUTION.** The reaper runs on/from main, foundation-owned. No module orc reaps. Single-writer-to-spine preserved.
5. **IDEMPOTENT + LOUD.** Every reap action logs to the decision-log (what was reaped, branch sha, why). A no-op is logged as a no-op. A HALT is logged loudly and surfaced — never swallowed. No fake closures: a worktree is reaped only on actual evidence of merged+clean or dead-owner, never on a status field alone.

## §3 — Reap-at-merge (normal path)

Trigger: foundation merges a seat/module branch into main.
1. Confirm the branch is fully merged (`git branch --merged main` includes it; or `git merge-base --is-ancestor <branch> main`).
2. Resolve the worktree bound to that branch (`git worktree list --porcelain`).
3. Force-remove guard (§2.1): `git status --porcelain` in the worktree is empty AND no unmerged/detached commits beyond main. If not → HALT + surface; do not reap.
4. Clean + merged → `git worktree remove <path>`, then `git branch -d <branch>` (safe delete, not `-D`), then `git worktree prune`.
5. Log the reap to decision-log with branch sha + worktree name.

## §4A — Owner-PID stamp at worktree-create (v0.2; required by §4.2)

The §7 readback confirmed **no owner/PID source exists today**. The §4 PID gate cannot distinguish a live owner from a dead one without one. Therefore the reaper mechanism MUST add a minimal owner stamp at the moment a worktree is created:

1. At `git worktree add` (the precondition-sweep site, §6), after creation, write an owner record: `.git/worktrees/<name>/owner` containing the launching session's PID and a UTC timestamp.
2. The stamp is **ephemeral, NEVER tracked** (same class as audit-done sentinels and `.claude/inbox-seen`).
3. §4.2 reads this PID for the liveness gate: `kill -0 <pid>` alive → leave; dead/absent → candidate for sweep (still subject to the §2.1 force-remove guard).
4. A worktree with NO owner stamp (created before this mechanism, or stamp lost) is treated as **unknown-owner → HALT and surface**, never auto-swept on absence alone. Absence of evidence is not evidence of a dead owner.

This closes the gap the readback surfaced and is the one substantive addition from v0.1 → v0.2.

## §4 — Stale-lock reaper (abandoned path)

Trigger: invoked before `git worktree add` (precondition sweep) and/or on a foundation-initiated maintenance pass.
1. Enumerate `.git/worktrees/*/` admin dirs and any `locked` / `index.lock` / `HEAD.lock` files.
2. For each lock, resolve the owning PID (from the worktree's recorded session/pid where available; the doorbell `.ready`/SessionEnd markers and any session pid-file are corroborating sources).
3. **PID alive → leave it (busy, not stale).** PID dead/absent → candidate for sweep.
4. Before removing a dead-owner worktree: force-remove guard (§2.1). Dirty/unmerged → HALT + surface (a crashed session may hold unsaved proposal work — that is exactly what must not be silently destroyed). Clean → `git worktree remove` + `git worktree prune` + lock cleanup.
5. Log every sweep + every HALT to decision-log.

## §5 — What this gate unblocks (downstream, not part of v1)

- Governance-topology §1/§2 — the three seat worktrees may be created once the reaper lands (the reap-at-merge counterpart now exists, so they will not orphan).
- GOVERNANCE-CHECK Phase-2 `scripts/governance.sh` — forward-queued alongside; not built by this spec.
Neither is provisioned by SPEC-REAPER; this spec only builds the lifecycle mechanism that is their precondition.

## §6 — Homes / composition (foundation/main code-track)

- Reaper logic → `scripts/reaper.sh` (or `reaper.py` if the force-remove guard logic warrants it; foundation's call on language, consistent with the inbox.sh/governance.sh family).
- Reap-at-merge trigger → wired into foundation's merge procedure (the §7 readback pins exactly where — explicit step in the integrate flow, not a git-native hook).
- Stale-lock precondition sweep → invoked at the head of whatever performs `git worktree add` (so it self-cleans before creating).
- Spec = governance (architect). Impl = foundation/main (foundation, sole committer).

## §7 — Pinning readback (ANSWERED at <sha>, decision-log)

1. **Merge procedure:** explicit `reap_at_merge.sh` step — **no git-native post-merge hook**. → §3's trigger is an explicit step in the integrate flow, NOT a hook. Spec updated accordingly.
2. **`git worktree add` site:** root siblings (contained-parent). → §4 precondition sweep + §4A owner-stamp wire in here.
3. **PID/owner source:** **none today.** → §4A added: owner-pid stamp at create is mandatory; §4.2 reads it.
4. **Issue body:** pasted verbatim in decision-log; this spec resolves it.
5. **Lock inventory:** **CLEAN** — zero `locked`/`.lock`; the prior stale set is gone. → §4 enumerates the real (currently empty) set; the mechanism is preventive going forward, not a cleanup of an existing mess.

## §8 — Acceptance criteria (what "the reaper works" means)

- **AC1 (reap-at-merge):** merge a test seat branch clean → worktree + branch removed, decision-log entry written, `git worktree list` no longer shows it.
- **AC2 (force-remove guard):** merge a branch whose worktree has uncommitted dirt → reaper HALTS, surfaces, does NOT remove; the dirt survives.
- **AC3 (PID gate):** a lock held by a LIVE session is left untouched; a lock whose owner PID is dead is swept.
- **AC4 (unmerged guard):** a worktree with detached/unmerged commits → HALT, not reaped.
- **AC5 (orphan-storm):** create N≥5 worktrees, merge all clean, run the reaper → all reaped, `git worktree add` of a reused name then succeeds (the incident no longer reproduces).
- **AC6 (idempotent/loud):** re-running the reaper on an already-clean tree is a logged no-op; every action and HALT appears in decision-log.
- **AC7 (owner-stamp gate):** a worktree created under §4A has an owner record; a live-PID owner is never swept; a dead-PID owner is swept (subject to §2.1); a worktree with NO owner stamp HALTS rather than being swept on absence.

## §9 — Sequencing

- Build queues behind active integration work unless operator reprioritizes (priority = operator; mechanism = architect/foundation).
- Build pinned on §7 readback.
- On land: gate clears → seat worktrees (topology §9) and `governance.sh` (GOVERNANCE-CHECK Phase-2) become buildable.
