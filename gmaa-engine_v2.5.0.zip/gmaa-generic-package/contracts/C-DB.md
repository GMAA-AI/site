# GENERICIZATION NOTE (FORM-1 ABSTRACTED per operator ruling 2026-08-06 — origin-grounded vs pin a0929259):
# All origin schema-qualifiers → {{SCHEMA}}/{{REF_SCHEMA}}/{{PUBLISH_SCHEMA}} slots (the §1 schema INVENTORY too).
# The direct-seed work-queue/publish-target/direct-seed+first-party sentinels → {{WORK_QUEUE}}/{{PUBLISH_TARGET}}/
# {{DIRECT_SEED_SENTINEL}}/{{FIRSTPARTY_SENTINEL}} slots. The distinctive origin object/column names that
# survived earlier passes were ABSTRACTED to neutral generic names (form-1, max low-disclosure): the
# table/column examples are now neutral generic illustrations, no origin-identifying object/column name
# remains, and NO "non-identifying kept names" claim is made (the distinctive names are gone by
# construction). [BINDING]/[INCIDENTAL] = generic column-classification vocabulary (method, not instance).
# Also stripped: real sproc names prefixed with project namespaces, real grantee identities, real object
# counts/timestamps from a live extraction, and all MUST-NOT-SHIP tokens. The CONTRACT SHAPE —
# BINDING/INCIDENTAL model, schema/table/column/constraint/index/sproc/grant/view/sentinel-data categories,
# mediated-write-zero invariant, and divergence-analysis sub-deliverable — is fully preserved and neutral.
# Slot {{DB_APP_USER}} = the adopter's workload principal.

# C-DB — Database Schema Interface Contract — v1.0

**Status:** v1.0 — frozen-candidate. The schema, table, column, constraint, index, sproc, grant, view,
and sentinel-data sections are authoritative. §12 open items are refinement-class, not contract-shape-class.

*One of the core interface contracts. The frozen contract the substrate track builds against, and the
verification spine (Rings 1–2) probes against.*

---

## §0 — Contract scope and rules of use

C-DB freezes the **physical database substrate** the adopter's SQL database provides to all consumers
(the research skill/enrichment track; the canvas/operator-surface track; the automation flows; the publishing
blueprints; the auditor; the deploy agents). It maps every binding promise consumers may rely on.

**A contract states only what a consumer may BIND to.** Each source item from the extraction is classified:

- **[BINDING]** — a relied-on guarantee that consumers depend on. Changes to BINDING items break consumers
  and require coordinated migration. Examples: schema names, table names, column names + types + nullability
  + CHECK constraints, sproc signatures (param names + types), FK relationships, GRANT model
  (per-grantee permissions).
- **[INCIDENTAL]** — true today, not guaranteed. Consumers must NOT depend on these. Examples: numeric
  `object_id` values (vary per-instance), `create_date` / `modify_date` timestamps (incidental
  administrative metadata), internal `index_id` numbering.

Where C-DB and live behavior diverge, the reconciliation pass (`probes/c-db/divergence_analysis_v1.sh`)
surfaces it via the 5-bucket delta (MATCH / CRUFT / RELIC-DATA / MISSING / DIVERGENT) and the contract or
the build is corrected — never paraphrased over.

**Mediated-write-zero invariant (`mediated-write-zero`):** `{{DB_APP_USER}}` (the workload application
principal — adopter fills this slot with their service-account identity) has zero direct DML
(`INSERT`/`UPDATE`/`DELETE`) on the research-tier and publish-tier tables BY DESIGN. Every write goes
through an EXECUTE-granted stored procedure (ownership-chaining model). Direct DML from `{{DB_APP_USER}}`
returns a permissions-denied error — this is the contract enforcing itself, not a misconfiguration.

Slot `{{DB_APP_USER}}` appears only in this contract as a documented placeholder. It must never be
replaced with a real service-account name or real credential in any generic engine artifact.

---

## §1 — Schemas — [BINDING]

The substrate exposes exactly these schemas. Consumers may bind to schema names. New schemas require contract
revision.

| schema_id | name | scope |
|---|---|---|
| (incidental) | `dbo` | system / catalog only; consumers do NOT write to dbo |
| (incidental) | `{{REF_SCHEMA}}` | reference / lookup tables (state machines, code lists); read-only for consumers; updated only via versioned migrations |
| (incidental) | `{{SCHEMA}}` | research-tier substrate (items, candidates, task_runs, gates, citations, etc.); sproc-only writes per `mediated-write-zero` invariant |
| (incidental) | `{{PUBLISH_SCHEMA}}` | publish-tier substrate (promoted items, comparison items, publish state transitions); promoted via `{{SCHEMA}}.sp_promote_*` family; sproc-only writes |
| (incidental) | `history` | system-versioning shadow for SYSTEM_VERSIONED tables; consumers do NOT directly query; admin-only |

`schema_id` numeric values are **[INCIDENTAL]** (per-instance assignment by the database engine).

---

## §2 — Tables — [BINDING per-name + per-shape]

**Inventory:** adoption target's extraction enumerates the full table set in `probes/c-db/extraction_<timestamp>.txt` §3 TABLES.

**Per-table-row from extraction shape:**
- `schema_name` — [BINDING]
- `table_name` — [BINDING]
- `object_id` — [INCIDENTAL]
- `temporal_type_desc` (NON_TEMPORAL_TABLE / SYSTEM_VERSIONED_TEMPORAL_TABLE) — [BINDING]
  (SYSTEM_VERSIONED tables behave differently — temporal query syntax, history management;
  consumers may depend on the distinction)
- `history_table_id` / `history_table_name` — [INCIDENTAL] (specific history table name is per-instance;
  consumers query the SYSTEM_VERSIONED parent only)

**Critical tables (representative BINDING enumeration — full list in extraction §3):**

| schema.table | temporal_type | role |
|---|---|---|
| `{{SCHEMA}}.items` | SYSTEM_VERSIONED | The core research-tier item entity; `canonical_name` + `model_identifier` + `item_id` identity; promoted via `sp_promote_item_to_publish`. |
| `{{SCHEMA}}.candidates` | SYSTEM_VERSIONED | Candidate substrate (queries + trend signals); direct-seed route uses `{{DIRECT_SEED_SENTINEL}}` sentinel; discovery route writes via `sp_upsert_candidate`. |
| `{{SCHEMA}}.task_runs` | NON_TEMPORAL | Task run lifecycle envelope (active / completed / halted); item_id binds to {{SCHEMA}}.items; candidate_id binds to {{SCHEMA}}.candidates. |
| `{{WORK_QUEUE}}` | NON_TEMPORAL | direct-seed automation-leg state machine (pending / extracting / source_fetching / verifying / completed / awaiting_disambiguation). |
| `{{SCHEMA}}.item_testing_notes` | NON_TEMPORAL | Per-item testing notes (operator hands-on prose; content-composer voice source). |
| `{{SCHEMA}}.sourcing_runs` | SYSTEM_VERSIONED | Discovery scan envelope (candidate seeder; pending_review / completed). |
| `{{SCHEMA}}.sourcing_candidates` | SYSTEM_VERSIONED | Discovery scan candidates (per-category top-N rankings). |
| `{{SCHEMA}}.citations` | NON_TEMPORAL | Per-URL evidence rows (CC-1/2/4 evidence-discipline; item_citations + candidate_citations junctions). |
| `{{PUBLISH_TARGET}}` | NON_TEMPORAL | Single-item publish-tier; status Ready→InProgress→Draft / Cancelled; `reviewer_notes` carries `{{FIRSTPARTY_SENTINEL}}` prepend per direct-seed route. |
| `{{PUBLISH_SCHEMA}}.comparison_items` | NON_TEMPORAL | Comparison-format publish-tier. |
| `{{PUBLISH_SCHEMA}}.state_transitions` | NON_TEMPORAL | Append-only publish lifecycle log; per-attempt provenance. |
| `{{REF_SCHEMA}}.item_states` | NON_TEMPORAL | Item state machine (in_progress / ready_for_approval / approved / rejected / hold). |
| `{{REF_SCHEMA}}.candidate_states` | NON_TEMPORAL | Candidate state machine (5 states: in_progress / ready_for_approval / approved / rejected / hold per state_code). |
| `{{REF_SCHEMA}}.human_halt_reasons` | NON_TEMPORAL | Halt taxonomy (verification_class: mechanical / operator_trust / terminal); `sp_run_resume` reads this. |

---

## §3 — Columns — [BINDING per-name + per-type + per-nullability + per-default-where-named]

**Inventory:** adoption target's extraction enumerates columns in `probes/c-db/extraction_<timestamp>.txt` §4 COLUMNS.

**Per-column-row from extraction:**
- `schema_name` / `table_name` — [BINDING]
- `column_id` — [INCIDENTAL] (positional)
- `column_name` — [BINDING]
- `type_name` — [BINDING] (e.g., `nvarchar`, `int`, `datetime2`, `bit`, `decimal`, `uniqueidentifier`)
- `bytes_or_chars` — [BINDING per-column] (max_length)
- `precision` / `scale` — [BINDING] for numeric / datetime2 columns
- `is_nullable` — [BINDING] (consumers depend on NULL-handling)
- `is_identity` — [BINDING] (consumers depend on IDENTITY semantics)
- `is_computed` — [BINDING]
- `default_constraint_def` (default value expression) — [BINDING per-column] where defined (e.g.,
  `season_class DEFAULT 'year_round'`; `created_at DEFAULT SYSUTCDATETIME()`)

**Width-units reminder (carried as constraint):** For SQL Server: NVARCHAR `max_length` is BYTES
(2 per char), not declared char-width. A declared `NVARCHAR(255)` reports `max_length=510`. Consumers
reading the extraction MUST apply ÷2 for NVARCHAR. This is a SQL Server engine idiom, not a contract
surface.

---

## §4 — Constraints — [BINDING]

### §4.1 — Primary / Unique constraints

- [BINDING] per-constraint: `schema_name`, `table_name`, `constraint_name`, `constraint_type`,
  `supporting_index_name`, `is_unique`, `has_filter` (filtered uniqueness), `filter_definition`
  (where readable).
- [INCIDENTAL]: internal `index_id` numbers.

**Critical filtered-uniqueness items:** filtered unique indexes (e.g., on item identity per corpus,
`WHERE item_id IS NOT NULL`) enable multi-null direct-seed seeds per corpus. `filter_definition` may
return NULL under restricted SP context; `has_filter=1` is dispositive. Admin context required for
authoritative predicate read.

### §4.2 — Foreign Key constraints

- [BINDING] per-FK: `schema.table` (referencing) + `referenced_table` (referenced) + `fk_name` +
  `on_delete` action + `on_update` action.
- [INCIDENTAL]: `is_disabled` (administrative state; should always be 0/enabled for live data).

### §4.3 — CHECK constraints

- [BINDING] per-CHECK: `schema.table` + `check_name` + `definition` (full body).
- [INCIDENTAL]: `is_disabled` / `is_not_trusted` (administrative).

**Pattern:** CHECK definitions carry domain logic (e.g., `CK_candidates_demand_indicator CHECK (demand_indicator IN ('absolute','relative_trend'))`). Consumers MUST satisfy these on INSERT/UPDATE (routed through sprocs per `mediated-write-zero`).

---

## §5 — Indexes — [BINDING per-name + per-filter-state]

**Inventory:** adoption target's extraction enumerates indexes in `probes/c-db/extraction_<timestamp>.txt` §6.

- [BINDING] per-index: `schema.table` + `index_name` + `type_desc` + `is_unique` + `is_primary_key` +
  `is_unique_constraint` + `has_filter`.
- [BINDING-where-readable]: `filter_definition` (restricted SP context may return NULL; admin context
  authoritative).
- [INCIDENTAL]: `index_id` numeric (positional).

Consumers may bind to index-name + filter-status for query-plan reasoning. The presence-of-an-index on a
column is BINDING; the specific physical structure (B-tree depth, page count, fill factor) is INCIDENTAL
operational state.

---

## §6 — Stored procedures — [BINDING per-signature]

**Inventory:** adoption target's extraction enumerates sprocs and their parameters in
`probes/c-db/extraction_<timestamp>.txt` §7a + §7b.

### §6.1 — Sproc shape

- [BINDING] per-sproc: `schema_name` + `sproc_name`.
- [INCIDENTAL]: `object_id` (per-instance numeric) + `create_date` / `modify_date` (administrative
  timestamps).

### §6.2 — Parameter signature

- [BINDING] per-parameter: `parameter_name` (e.g., `@item_id`) + `type_name` + `bytes_or_chars` (with
  NVARCHAR ÷2 reminder) + `precision` + `scale` + `is_output`.
- [BINDING per-sproc] `has_default_value` (whether a default exists; may be unreliable for string defaults
  per engine docs — verify in sproc body when needed).
- [INCIDENTAL]: `parameter_id` (positional, but parameter order IS semantically meaningful for positional
  callers; consumers should use named params per project convention).
- [INCIDENTAL where unreliable]: `default_value` for string defaults (engine limitation; read from body).

**Naming convention (BINDING):** All sprocs in the `{{SCHEMA}}.*` and `{{PUBLISH_SCHEMA}}.*` schemas. Parameter names
always `@`-prefixed. Output params suffixed `OUTPUT` in CREATE / call signatures.

### §6.3 — Critical sproc inventory (representative BINDING enumeration; full list in extraction §7a)

**Direct-seed route (first-fire path; verified PRESENT + GRANTED):**
- `{{SCHEMA}}.sp_create_direct_seed_item` (atomic create+enqueue)
- `{{SCHEMA}}.sp_attach_notes` (firstparty_marker)
- `{{SCHEMA}}.sp_enqueue_direct_seed_research` (sp_create composes this)
- `{{SCHEMA}}.sp_match_existing_item` (READ-ONLY; identity-exact + name+model match)
- `{{SCHEMA}}.sp_task_run_start_direct_seed` (linkage primitive)
- `{{SCHEMA}}.sp_run_complete_direct_seed` (8-gate CTE)
- `{{SCHEMA}}.sp_run_resume` (halt taxonomy reads {{REF_SCHEMA}}.human_halt_reasons)
- `{{SCHEMA}}.sp_run_complete` (non-direct-seed close)
- `{{SCHEMA}}.sp_verify_item` (Gate G8)
- `{{SCHEMA}}.sp_promote_item_to_publish` (research-schema not publish; `{{FIRSTPARTY_SENTINEL}}` prepend logic)
- `{{SCHEMA}}.sp_branch_decide` (Two-Tier approval)
- `{{SCHEMA}}.sp_check_completeness` (Gate G12 validator; {{FIRSTPARTY_SENTINEL}} cardinality rule)

**Discovery route + gate-writer family + citation + per-attribute write sprocs:** see extraction §7a
(full list).

---

## §7 — GRANTs — [BINDING per-object × per-grantee]

**Inventory:** adoption target's extraction enumerates grants in `probes/c-db/extraction_<timestamp>.txt`
§8 GRANTS.

- [BINDING] per-grant: `schema.object_name` + `grantee` + `permission_name` (EXECUTE / SELECT / etc.) +
  `state_desc` (GRANT / GRANT_WITH_GRANT_OPTION).

### §7.1 — Grantee model

- **Canvas/operator principal** — database role; canvas-facing principal; EXECUTE grants on
  canvas-callable sprocs.
- **`{{DB_APP_USER}}`** — workload application principal (adopter fills slot with their service-account
  identity); EXECUTE grants on skill-internal sprocs only; zero direct DML on any research-tier or
  publish-tier table (the `mediated-write-zero` invariant). Transitively inherits canvas-role grants if
  added to the role.

### §7.2 — Visibility caveat

`OBJECT_ID()` returns NULL for objects on which the caller has no permission. A restricted-context probe
MAY return NULL for an object that exists but isn't granted to that context. Mitigation: cross-check
`sys.database_permissions` per-grantee + (where ambiguous) escalate to admin-context read for ground truth.

---

## §8 — User-defined types — [BINDING when present]

If the adoption substrate uses user-defined types, full type definition is BINDING. Document in the
adoption-target extraction §9. Where 0 user-defined types are present, this section is a no-op for
the current substrate version.

---

## §9 — Views — [BINDING per-name + per-column-projection]

**Inventory:** adoption target's extraction enumerates views in `probes/c-db/extraction_<timestamp>.txt`
§10 VIEWS.

- [BINDING] per-view: `schema.view_name` + the column projection (the SELECT list).
- [BINDING] per-view: the predicate (WHERE clause) where readable; restricted SP context may return NULL
  via `OBJECT_DEFINITION()`; admin context authoritative.
- [INCIDENTAL]: `object_id` + `create_date` / `modify_date`.

**Critical views (representative; full list in extraction §10):**
- `{{SCHEMA}}.v_candidates_pending_approval` — Branch-A canvas data target; filter excludes `{{DIRECT_SEED_SENTINEL}}`
  sentinels (state=approved by construction).
- `{{PUBLISH_SCHEMA}}.v_items_publishing` — publish-tier data target.
- `{{SCHEMA}}.v_author_verification` — author credential verification data.

---

## §10 — Sentinel data — [BINDING per-pattern]

Some seeded data is part of the contract because consumers depend on its presence:

- `{{SCHEMA}}.candidates WHERE query_text = '{{DIRECT_SEED_SENTINEL}}'` — adopter-configured count per corpus
  (state=approved; format_kind matches a review-stage equivalent). [BINDING]: existence + state +
  format_kind for each corpus.
- `{{REF_SCHEMA}}.candidate_states` seed: 5 states (in_progress / ready_for_approval / approved / rejected / hold per
  `state_code`). [BINDING]: each state_code present + `is_terminal=0` for all 5.
- `{{REF_SCHEMA}}.item_states` seed: item lifecycle states (in_progress / ready_for_approval / approved / rejected /
  hold). [BINDING]: each state_code present.
- `{{REF_SCHEMA}}.human_halt_reasons` seed: halt taxonomy with `verification_class` (mechanical / operator_trust /
  terminal). [BINDING]: each halt_reason_code's verification_class.

---

## §11 — Divergence analysis (sub-deliverable)

The divergence analysis script + output land alongside this contract:

- `probes/c-db/divergence_analysis_v1.sh` — re-runnable; re-extracts live + diffs vs this canonical
  contract; emits per-object 5-bucket delta (MATCH / CRUFT / RELIC-DATA / MISSING / DIVERGENT).
- `probes/c-db/divergence_<timestamp>.md` — the 5-bucket per-object delta output.

`_escalations/002` (database-decision: rebuild fresh vs keep live) binds on this artifact's evidence,
NOT on prior reasoning.

---

## §12 — Open items for FROZEN gate

Open items for architect attention:

1. **Per-object exhaustive BINDING/INCIDENTAL marks** — this v1.0 uses BINDING-by-default per category
   with INCIDENTAL items explicitly enumerated. Full per-object marking may be added in v1.1.
2. **Sentinel data placement** — §10 sentinel data sits in C-DB; alternative is to fold into
   the operational-invariants contract per `docs/PROTOCOL.md` §3.
3. **VIEW body — BINDING or INCIDENTAL?** — views' SELECT list + WHERE clause are BINDING per consumer
   behavior. But the view's exact SQL implementation is INCIDENTAL (refactoring the body without changing
   the output is permitted). DRAFT marks projection+predicate BINDING. Confirm.
4. **Index `filter_definition` reading caveat** — captured in §5; admin context authoritative; restricted
   context may NULL. Confirm handling.

---

END OF C-DB v1.0.
