#!/usr/bin/env bash
# scripts/inbox.sh — lane-resolved SPINE-inbox reader (routing; hub-and-spoke relay engine).
#
# GENERICIZATION NOTE: unchanged from origin — already fully generic (spine branch = `main`,
# lane resolved via resolve-lane.sh, no instance IDs). `foundation` here is the generic integrator
# lane name (kept per the base census foundation + executor + {{MODULE_LANE}}).
#
# WHY: the inbox is stored on the spine and read CROSS-REF (`git show main:…`); the module branch
# never carries inbox writes (integration-excluded by design — keeps the branch clean + stops inbox
# content leaking back to spine). Consequence: inbound is NOT filesystem-visible in the module
# worktree — a plain `ls`/Read MISSES it (the silent-miss / fail-open the routing ratify left open).
# This helper is the seamless read; the INBOX-CHECK invariant (orc.md) is the liveness half.
#
# INVARIANT (orc.md, binding for module lanes): run this as the FIRST action of EVERY turn and emit
#   INBOX-CHECK: <lane> <N new | empty>
# If N new → CONSUME-BEFORE-PROCEED: read + reconcile the inbound BEFORE the intended turn, THEN
# `consume`. The last-seen marker advances ONLY on explicit consume (you ACTED) — NEVER on a plain
# read, else a glanced-past read marks seen and recreates the silent-miss one layer down.
#
# Usage:
#   scripts/inbox.sh                  # check: emit INBOX-CHECK line + bodies of NEW messages (no advance).
#                                     #   Also snapshots the DISPLAYED set to .claude/inbox-shown.
#   scripts/inbox.sh consume NAME...  # mark NAME(s) consumed — ONLY after acting on them.
#   scripts/inbox.sh consume --all    # mark consumed ONLY what the LAST check displayed (shown-snapshot ∩
#                                     #   still-pending) — NOT the live spine set. A relay arriving after the
#                                     #   check survives (no swallow-unread). HALTs if no prior check ran.
#
# Identity: lane resolves from _boot via scripts/resolve-lane.sh (the single identity-definition site;
# never re-implemented here). Exit 3 = HALT on unresolved lane (never default to the integrator lane).
set -u

REPO_ROOT="$(git rev-parse --show-toplevel 2>/dev/null)" || { echo "inbox.sh: not in a git worktree" >&2; exit 2; }
cd "$REPO_ROOT" || exit 2

EVAL="$(scripts/resolve-lane.sh)" || { echo "inbox.sh: HALT — lane unresolved (resolve-lane.sh non-zero)" >&2; exit 3; }
eval "$EVAL"
: "${lane:?inbox.sh: HALT — lane empty after resolve}"

INBOX="_orchestration/relay-inbox/${lane}"
MARKER=".claude/inbox-seen"   # gitignored (.claude/* except !.claude/agents/); per-worktree = per-lane
SHOWN=".claude/inbox-shown"   # gitignored snapshot: the names the MOST-RECENT check displayed. `consume --all`
                              # is bounded by this set (never the live spine set) — closes the TOCTOU swallow
                              # where a relay landing AFTER a check but BEFORE a blind consume --all was marked
                              # seen unread (silent message-loss; a prior consume-all message-loss defect).

list_pending() {  # spine inbox basenames, excluding .gitkeep; empty if no dir for this lane
  git ls-tree --name-only "main:${INBOX}/" 2>/dev/null | grep -v '^\.gitkeep$' || true
}
is_seen() { [[ -f "$MARKER" ]] && grep -qxF "$1" "$MARKER"; }

cmd="${1:-check}"
case "$cmd" in
  check)
    new=()
    while IFS= read -r f; do
      [[ -n "$f" ]] || continue
      is_seen "$f" || new+=("$f")
    done <<< "$(list_pending)"
    # SNAPSHOT the shown set (overwrite every check). consume --all may ONLY mark THESE seen — never
    # the live spine set — so a relay that lands AFTER this check is not in the snapshot and always
    # survives a subsequent consume --all. Truncate first so an empty check leaves an empty snapshot.
    mkdir -p "$(dirname "$SHOWN")"; : > "$SHOWN"
    if [[ ${#new[@]} -eq 0 ]]; then
      echo "INBOX-CHECK: ${lane} empty"
      # Visibility: an empty inbox is never a mysterious blank — show what WAS consumed so a
      # previously-consumed (or wrongly-swallowed) message is auditable at a glance.
      if [[ -s "$MARKER" ]]; then
        echo "  ($(grep -c . "$MARKER" 2>/dev/null || echo 0) consumed to date; most recent: $(tail -1 "$MARKER" 2>/dev/null))"
      fi
      exit 0
    fi
    printf '%s\n' "${new[@]}" >> "$SHOWN"
    echo "INBOX-CHECK: ${lane} ${#new[@]} new"
    for f in "${new[@]}"; do
      echo "===== NEW: ${INBOX}/${f} ====="
      git show "main:${INBOX}/${f}"
      echo "===== END: ${f} ====="
      echo
    done
    echo "[consume only after acting: scripts/inbox.sh consume ${new[*]} ]"
    ;;
  consume)
    shift
    mkdir -p "$(dirname "$MARKER")"; : >> "$MARKER"
    in_shown() { [[ -f "$SHOWN" ]] && grep -qxF "$1" "$SHOWN"; }
    if [[ "${1:-}" == "--all" ]]; then
      # STRICT: consume ONLY what the most-recent check DISPLAYED (SHOWN ∩ still-pending ∩ unseen).
      # NEVER the live spine-pending set — that blind sweep is the swallow-unread bug (a relay arriving
      # between check and consume was marked seen without ever being read). Absent snapshot = HALT-LOUD.
      [[ -f "$SHOWN" ]] || { echo "inbox.sh consume --all: HALT — no shown-snapshot; run \`scripts/inbox.sh\` (check) first (consume --all only marks what a prior check displayed)" >&2; exit 3; }
      pend="$(list_pending)"; n=0
      while IFS= read -r f; do
        [[ -n "$f" ]] || continue
        is_seen "$f" && continue
        printf '%s\n' "$pend" | grep -qxF "$f" || continue   # must still be pending on the spine
        echo "$f" >> "$MARKER"; n=$((n+1))
      done < "$SHOWN"
      echo "inbox.sh: consumed ${n} shown+pending message(s) for ${lane} (shown-snapshot bound; un-shown arrivals preserved)"
    else
      [[ $# -eq 0 ]] && { echo "inbox.sh consume: name(s) required (or --all)" >&2; exit 2; }
      for f in "$@"; do
        in_shown "$f" || echo "inbox.sh consume: WARNING — '$f' was not in the last check's shown-set (did you read it? consuming by explicit request)" >&2
        is_seen "$f" || echo "$f" >> "$MARKER"
      done
      echo "inbox.sh: consumed ${*} for ${lane}"
    fi
    ;;
  *)
    echo "inbox.sh: unknown cmd '$cmd' (use: check | consume)" >&2; exit 2 ;;
esac
