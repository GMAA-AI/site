#!/usr/bin/env bash
# scripts/governance.sh <topic...> — GOVERNANCE-CHECK Phase 2 (cite-before-raise / cite-before-reopen).
#
# GENERICIZATION NOTE: unchanged from origin — already fully generic (spine = `main`, reads
# decision-log.md / issues_register.md / contracts/**, zero instance IDs).
#
# WHY: "no settled decision is re-raised" (issues_register header). Phase 1 = the orc.md invariant (self-run,
# skippable). This is Phase 2: an enforcer that greps the CHRONOLOGICAL INDEX independent of an agent's own
# compliance — the same way the post-commit auditor hook fires regardless of the persona. Run it BEFORE
# raising an issue / routing a "blocker" / reopening a settled decision.
#
# READ ORDER (supersession-aware — the LATEST dated state wins, never the first match):
#   1. decision-log.md    (already ruled?)
#   2. issues_register.md  (already resolved? at what LATEST state?)
#   3. contracts/**        (the current frozen rule the above point to)
# Sourced from the SPINE via `git show main:` so it is correct from ANY lane worktree. Read-only; zero API/SQL.
#
# Usage:  scripts/governance.sh <keyword> [more keywords...]      # ORs the keywords into one case-insensitive pattern
# Emits:  GOVERNANCE-CHECK: <topic> answered@<refs>   (DO NOT raise/reopen — cite the ref)
#     or: GOVERNANCE-CHECK: <topic> silent-or-contradictory   (raise/reopen IS legitimate; attach this read)
set -u

[[ $# -ge 1 ]] || { echo "usage: governance.sh <keyword> [more keywords...]" >&2; exit 2; }
topic="$*"
# Build a case-insensitive ERE from all args (space-separated -> alternation).
pat=""; for w in "$@"; do w="${w//[^A-Za-z0-9_.-]/}"; [[ -n "$w" ]] || continue; pat="${pat:+$pat|}$w"; done
[[ -n "$pat" ]] || { echo "governance.sh: no usable keyword after sanitising '$topic'" >&2; exit 2; }

REPO_ROOT="$(git rev-parse --show-toplevel 2>/dev/null)" || { echo "governance.sh: not in a git worktree" >&2; exit 2; }
cd "$REPO_ROOT" || exit 2
eval "$(scripts/resolve-lane.sh 2>/dev/null)" 2>/dev/null || true
lane="${lane:-?}"

DLOG="$(git show main:_orchestration/decision-log.md 2>/dev/null || true)"
IREG="$(git show main:issues_register.md 2>/dev/null || true)"

# 1) decision-log hits (line-numbered; agent applies supersession — newest dated entry wins)
dlog_hits="$(printf '%s\n' "$DLOG" | grep -niE "$pat" 2>/dev/null | head -10 || true)"
# 2) issues_register hits (ISSUE headers + Status carry the LATEST resolved/reopened state)
ireg_hits="$(printf '%s\n' "$IREG" | grep -niE "$pat" 2>/dev/null | head -10 || true)"
# 3) contracts whose filename matches the topic (the frozen rule)
cfiles="$(git ls-tree -r --name-only main -- contracts 2>/dev/null | grep -iE "$pat" 2>/dev/null || true)"

hit=0; [[ -n "$dlog_hits$ireg_hits$cfiles" ]] && hit=1

echo "── GOVERNANCE-CHECK (lane=$lane · topic='$topic' · through main HEAD $(git rev-parse --short main 2>/dev/null)) ──"
if [[ "$hit" -eq 1 ]]; then
  echo "GOVERNANCE-CHECK: ${topic} answered@[index-hits-below] — READ the LATEST dated state, then CITE it. DO NOT re-raise/re-derive."
  if [[ -n "$dlog_hits" ]]; then echo; echo "  decision-log.md (§ ruled? — newest dated entry wins):"; printf '%s\n' "$dlog_hits" | sed 's/^/    /'; fi
  if [[ -n "$ireg_hits" ]]; then echo; echo "  issues_register.md (resolved? at what LATEST state? read the full RESOLVED->REOPENED->RE-CLOSED chain):"; printf '%s\n' "$ireg_hits" | sed 's/^/    /'; fi
  if [[ -n "$cfiles"    ]]; then echo; echo "  contracts/** (the frozen rule):"; printf '%s\n' "$cfiles" | sed 's/^/    /'; fi
  echo; echo "  RULE: if the read covers your topic -> the issue does not exist; drop it, cite the ref. Only silence/contradiction licenses a raise."
  exit 0
else
  echo "GOVERNANCE-CHECK: ${topic} silent-or-contradictory — no chronological-index hit through main HEAD."
  echo "  A raise/reopen IS legitimate. Attach this read as evidence: what you checked (decision-log+issues_register+contracts), the HEAD, and the gap."
  exit 1
fi
