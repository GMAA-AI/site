#!/usr/bin/env bash
# scripts/reaper.sh — worktree-lifecycle reaper. Implements SPEC-REAPER v0.2
# (contracts/SPEC-REAPER.md). Provides the reap-at-merge cleanup + stale-lock reaper
# + force-remove guard (SPEC-REAPER §3/§4/§2).
#
# GENERICIZATION NOTE: mechanism byte-unchanged from origin; this is a fully lane-agnostic
# worktree garbage-collector (no project lane names, no real IDs — it operates on whatever
# worktrees/branches exist). Genericized only: the two project ruling-number citations in the
# header/impl-note → rule-stated, and the instance date on the V0.2-IMPL NOTE stripped. The
# `foundation` lane (base-census integrator seat) and `main` (trunk ref) are GENERIC-KEEP; the
# spec `contracts/SPEC-REAPER.md` ships as an engine contract. NOTE vs the standalone
# `reap_at_merge.sh` (which MERGES module/<lane> into the spine + re-audits): this tool's
# `reap-at-merge` subcommand is the COMPLEMENT — it REMOVES the now-merged worktree + prunes.
#
# FOUNDATION-ONLY (§2.4). Subcommands:
#   reap-at-merge <branch>     §3 — normal path: branch merged into main AND its worktree
#                                   clean -> git worktree remove + branch -d + prune. Else HALT.
#   sweep                      §4 — abandoned path: enumerate worktree admin dirs + locks;
#                                   PID-gated; SAFE-BY-DEFAULT (unknown/uncorroborated owner ->
#                                   HALT+surface, never auto-remove). See V0.2-IMPL NOTE.
#   stamp <path> [pid]         §4A — write/refresh the owner-pid stamp for an existing worktree.
#   add <path> <branch> [base] §6 — sweep-precondition + git worktree add + §4A stamp (create site).
#   list                       diagnostic (read-only): worktrees + owner stamps + liveness.
#
# INVARIANTS (§2; violation = HALT, exit !=0, surfaced):
#   1 NO SILENT DATA LOSS — a worktree with uncommitted dirt OR detached/unmerged commits is
#     NEVER auto-force-removed. Detect FIRST; either present -> HALT+surface. Never `remove --force`.
#   2 PID-GATED not age-gated — a lock/worktree is swept only on a CONFIRMED-DEAD owner.
#   3 REAP ONLY MERGED+CLEAN on the normal path.
#   4 FOUNDATION-ONLY EXECUTION (resolve-lane.sh == foundation).
#   5 IDEMPOTENT + LOUD — material actions + HALTs append to the decision-log; routine no-op
#     liveness appends to ledger/reaper-runs.log. Re-run on a clean tree = logged no-op.
#
# V0.2-IMPL NOTE (surfaced to the architect via the decision-log): §4A stamps the CREATE-command
# PID, which is NOT the live session pid (the session launches AFTER `git worktree add`, at
# session-name/doorbell time). So §4.2's PID-liveness gate has no true live-session source until
# the launch wrapper stamps the session pid. THEREFORE this v1 sweep is SAFE-BY-DEFAULT: it never
# auto-removes; an unknown/uncorroborated owner -> HALT+surface (§4A.4). Auto-PID-sweep activates
# once a session-pid source exists (v0.3 / doorbell). reap-at-merge (§3, the primary path) is
# FULLY active and is what unblocks the seat worktrees (§5).
#
# TEST SEAM: REAPER_TEST=1 bypasses ONLY the §2.4 foundation-lane guard (for the contained /tmp
# harness) and redirects logs to $REAPER_LOG_DIR. ALL safety guards (force-remove, merged-check,
# PID gate, HALT-on-unknown) stay live. Mirrors the post-commit hook's AUDITOR_CMD test seam.
set -u

REPO_ROOT="$(git rev-parse --show-toplevel 2>/dev/null)" || { echo "HALT: not in a git repo"; exit 1; }
cd "$REPO_ROOT" || { echo "HALT: cannot cd to repo root"; exit 1; }
GIT_COMMON="$(git rev-parse --git-common-dir)"; case "$GIT_COMMON" in /*) : ;; *) GIT_COMMON="$REPO_ROOT/$GIT_COMMON" ;; esac
MAIN_REF="${REAPER_MAIN_REF:-main}"

# --- §5 logging sinks ---
LOG_DIR="${REAPER_LOG_DIR:-$REPO_ROOT}"
DECISION_LOG="$LOG_DIR/_orchestration/decision-log.md"
RUNS_LOG="$LOG_DIR/ledger/reaper-runs.log"
NOW() { date -u +%Y-%m-%dT%H:%M:%SZ; }
log_material() {  # $1=action $2=detail  -> decision-log (loud, curated)
    mkdir -p "$(dirname "$DECISION_LOG")" 2>/dev/null || true
    printf '\n### %s — [reaper] %s\n%s\n' "$(NOW)" "$1" "$2" >> "$DECISION_LOG" 2>/dev/null || true
}
log_run() {  # $1=line -> liveness log
    mkdir -p "$(dirname "$RUNS_LOG")" 2>/dev/null || true
    printf '%s [reaper] %s\n' "$(NOW)" "$1" >> "$RUNS_LOG" 2>/dev/null || true
}
halt() {  # $1=detail ; loud + logged + nonzero
    echo "HALT(reaper): $1" >&2
    log_material "HALT" "$1"
    exit 2
}

# --- §2.4 foundation-only guard (test seam: REAPER_TEST bypasses ONLY this) ---
if [[ "${REAPER_TEST:-0}" != "1" ]]; then
    if LANE_LINE="$("$REPO_ROOT/scripts/resolve-lane.sh" 2>/dev/null)"; then eval "$LANE_LINE"; fi
    [[ "${lane:-}" == "foundation" ]] || { echo "HALT(reaper): foundation-only (lane='${lane:-UNRESOLVED}')." >&2; exit 3; }
fi

# --- helpers ---
owner_file_for_name() { printf '%s/worktrees/%s/owner' "$GIT_COMMON" "$1"; }

# resolve the admin NAME for a worktree PATH (admin name = dir under $GIT_COMMON/worktrees whose
# gitdir points back into <path>). Echoes name or empty.
name_for_path() {
    local target="$1" wdir gd
    for wdir in "$GIT_COMMON"/worktrees/*/; do
        [[ -d "$wdir" ]] || continue
        gd="$(cat "$wdir/gitdir" 2>/dev/null)"            # -> <path>/.git
        [[ -n "$gd" ]] || continue
        # compare PHYSICAL paths (pwd -P) so a /tmp -> /private/tmp style symlink can't break the match
        if [[ "$(cd "$(dirname "$gd")" 2>/dev/null && pwd -P)" == "$(cd "$target" 2>/dev/null && pwd -P)" ]]; then
            basename "$wdir"; return 0
        fi
    done
    return 1
}

# path bound to a branch (via `git worktree list --porcelain`). Echoes path or empty.
path_for_branch() {
    local br="$1" cur="" line
    while IFS= read -r line; do
        case "$line" in
            "worktree "*) cur="${line#worktree }" ;;
            "branch refs/heads/$br") echo "$cur"; return 0 ;;
        esac
    done < <(git worktree list --porcelain 2>/dev/null)
    return 1
}

# §2.1 force-remove guard: returns 0 if SAFE to remove (clean + not detached + not unmerged-ahead),
# nonzero with a reason on stderr otherwise. NEVER removes.
worktree_safe_to_remove() {
    local path="$1" reason
    [[ -d "$path" ]] || { echo "path absent"; return 0; }  # already gone = safe no-op
    if [[ -n "$(git -C "$path" status --porcelain 2>/dev/null)" ]]; then
        echo "uncommitted changes present"; return 1
    fi
    if ! git -C "$path" symbolic-ref -q HEAD >/dev/null 2>&1; then
        echo "detached HEAD"; return 1
    fi
    # commits on this worktree's HEAD not reachable from main = unmerged work
    local ahead; ahead="$(git -C "$path" rev-list --count "$MAIN_REF"..HEAD 2>/dev/null || echo 0)"
    if [[ "${ahead:-0}" -gt 0 ]]; then
        echo "$ahead unmerged commit(s) ahead of $MAIN_REF"; return 1
    fi
    return 0
}

# ===================== §3 reap-at-merge (normal path) =====================
cmd_reap_at_merge() {
    local br="${1:?usage: reap-at-merge <branch>}"
    git rev-parse --verify -q "refs/heads/$br" >/dev/null 2>&1 || halt "no such branch: $br"
    # invariant 3: must be merged into main
    git merge-base --is-ancestor "refs/heads/$br" "$MAIN_REF" 2>/dev/null \
        || halt "branch '$br' is NOT merged into $MAIN_REF — refusing to reap (invariant §2.3)."
    local path; path="$(path_for_branch "$br")"
    if [[ -z "$path" ]]; then
        # merged branch, no bound worktree -> safe-delete the branch only
        git branch -d "$br" >/dev/null 2>&1 && { log_material "branch-reaped (no worktree)" "branch=$br merged into $MAIN_REF; \`git branch -d\` ok"; echo "reaped branch $br (no worktree bound)"; return 0; }
        halt "branch '$br' merged but \`git branch -d\` refused — inspect."
    fi
    local sha; sha="$(git -C "$path" rev-parse --short HEAD 2>/dev/null || echo '?')"
    # invariant 1+3: force-remove guard
    local why; if ! why="$(worktree_safe_to_remove "$path")"; then
        halt "reap-at-merge('$br'): worktree $path is NOT safe to remove ($why). NOT removed; dirt/work preserved."
    fi
    git worktree remove "$path" 2>/dev/null || halt "git worktree remove $path failed (not forced — inspect)."
    git branch -d "$br" >/dev/null 2>&1 || echo "note: branch -d $br deferred (already gone or refused)" >&2
    git worktree prune 2>/dev/null || true
    log_material "reap-at-merge" "branch=$br (sha=$sha) merged into $MAIN_REF; worktree=$path removed (clean); branch -d; prune. (no fake closure: removed only on merged+clean evidence)"
    echo "reaped: worktree=$path branch=$br (merged+clean)"
}

# ===================== §4 stale-lock sweep (abandoned path) =====================
cmd_sweep() {
    local candidates=() unknowns=() halted=0 acted=0 wdir name owner pid live
    for wdir in "$GIT_COMMON"/worktrees/*/; do
        [[ -d "$wdir" ]] || continue
        name="$(basename "$wdir")"
        local gd path; gd="$(cat "$wdir/gitdir" 2>/dev/null)"; path="$(dirname "$gd" 2>/dev/null)"
        owner="$(owner_file_for_name "$name")"
        if [[ ! -f "$owner" ]]; then
            unknowns+=("$name (path=$path): NO owner stamp -> unknown-owner")
            continue
        fi
        pid="$(sed -n 's/^pid=//p' "$owner" 2>/dev/null | head -1)"
        if [[ -z "$pid" ]] || ! [[ "$pid" =~ ^[0-9]+$ ]]; then
            unknowns+=("$name: owner stamp has no usable pid -> unknown-owner"); continue
        fi
        if kill -0 "$pid" 2>/dev/null; then
            log_run "sweep: $name owner pid=$pid ALIVE -> left (busy)."
        else
            # dead owner -> candidate, but §2.1 force-remove guard still gates removal
            local why
            if why="$(worktree_safe_to_remove "$path")"; then
                candidates+=("$name|$path|$pid")
            else
                halted=1
                log_material "HALT sweep candidate" "$name (path=$path) owner pid=$pid DEAD but NOT safe ($why) — preserved, not removed (invariant §2.1)."
                echo "HALT: $name dead-owner but unsafe ($why) — preserved." >&2
            fi
        fi
    done
    # also note any raw locks (clean inventory expected today)
    local locks; locks="$(find "$GIT_COMMON" -maxdepth 3 \( -name locked -o -name index.lock -o -name HEAD.lock \) 2>/dev/null)"
    [[ -n "$locks" ]] && echo "locks present:" && echo "$locks" | sed 's/^/  /'

    if [[ ${#unknowns[@]} -gt 0 ]]; then
        printf 'HALT: %d worktree(s) with unknown owner — NOT swept on absence (§4A.4 + V0.2-IMPL NOTE):\n' "${#unknowns[@]}" >&2
        printf '  - %s\n' "${unknowns[@]}" >&2
        log_material "sweep HALT (unknown-owner)" "$(printf '%s; ' "${unknowns[@]}")(safe-by-default: absence of a live-session pid source is NOT evidence of a dead owner; auto-sweep awaits the doorbell session-pid stamp.)"
        exit 2
    fi
    if [[ ${#candidates[@]} -eq 0 ]]; then
        log_run "sweep: no-op (no dead-owner clean candidates; ${halted:+halted=$halted}). Tree clean."
        echo "sweep: no-op (clean; nothing to reap)."
        return 0
    fi
    local c name path pid
    for c in "${candidates[@]}"; do
        IFS='|' read -r name path pid <<< "$c"
        git worktree remove "$path" 2>/dev/null && git worktree prune 2>/dev/null
        acted=$((acted+1))
        log_material "sweep reap (dead-owner clean)" "$name path=$path owner-pid=$pid DEAD + clean -> removed + prune."
        echo "swept: $name (dead owner pid=$pid, clean)"
    done
    echo "sweep: reaped $acted dead-owner clean worktree(s)."
}

# ===================== §4A owner-pid stamp =====================
cmd_stamp() {
    local path="${1:?usage: stamp <path> [pid]}" pid="${2:-$$}" name
    name="$(name_for_path "$path")" || halt "stamp: no registered worktree at $path"
    local of; of="$(owner_file_for_name "$name")"
    { printf 'pid=%s\n' "$pid"; printf 'stamped=%s\n' "$(NOW)"; printf 'pid_source=%s\n' "${REAPER_PID_SOURCE:-create-context}"; } > "$of"
    log_run "stamp: $name owner pid=$pid source=${REAPER_PID_SOURCE:-create-context}"
    echo "stamped $name -> pid=$pid (source=${REAPER_PID_SOURCE:-create-context})"
}

# ===================== §6 add (create site: sweep-precondition + add + stamp) =====================
cmd_add() {
    local path="${1:?usage: add <path> <branch> [base]}" br="${2:?usage: add <path> <branch> [base]}" base="${3:-$MAIN_REF}"
    cmd_sweep || echo "note: precondition sweep raised a HALT (unknown-owner) — review before relying on add." >&2
    if git rev-parse --verify -q "refs/heads/$br" >/dev/null 2>&1; then
        git worktree add "$path" "$br" || halt "git worktree add $path $br failed"
    else
        git worktree add "$path" -b "$br" "$base" || halt "git worktree add $path -b $br $base failed"
    fi
    cmd_stamp "$path" "$$"
    log_material "worktree-add" "path=$path branch=$br base=$base + owner stamp (create-context pid)."
    echo "added worktree $path on $br"
}

# ===================== diagnostic list =====================
cmd_list() {
    local wdir name gd path owner pid state
    printf '%-22s %-10s %-8s %s\n' "WORKTREE" "OWNER-PID" "LIVE" "PATH"
    for wdir in "$GIT_COMMON"/worktrees/*/; do
        [[ -d "$wdir" ]] || continue
        name="$(basename "$wdir")"; gd="$(cat "$wdir/gitdir" 2>/dev/null)"; path="$(dirname "$gd" 2>/dev/null)"
        owner="$(owner_file_for_name "$name")"
        if [[ -f "$owner" ]]; then
            pid="$(sed -n 's/^pid=//p' "$owner" | head -1)"
            if [[ -n "$pid" ]] && kill -0 "$pid" 2>/dev/null; then state="alive"; else state="DEAD/absent"; fi
        else pid="-"; state="no-stamp"; fi
        printf '%-22s %-10s %-8s %s\n' "$name" "${pid:--}" "$state" "$path"
    done
}

case "${1:-}" in
    reap-at-merge) shift; cmd_reap_at_merge "$@" ;;
    sweep)         shift; cmd_sweep "$@" ;;
    stamp)         shift; cmd_stamp "$@" ;;
    add)           shift; cmd_add "$@" ;;
    list)          shift; cmd_list "$@" ;;
    *) echo "usage: reaper.sh {reap-at-merge <branch>|sweep|stamp <path> [pid]|add <path> <branch> [base]|list}" >&2; exit 1 ;;
esac
