#!/usr/bin/env bash
# scripts/status.sh — observable state WITHOUT attaching to a pane.
#
# GENERICIZATION NOTE: mechanism unchanged; the instance lane list is genericized to the base census
# (adopters add their {{MODULE_LANE}} lanes), and the project-specific operator-custody queue block
# (real post/resource IDs) is replaced with a neutral placeholder the adopter fills from LATEST.md.
#
# Answers "what needs me right now" from one command: per-lane {head, last-outbox, inbox-pending,
# tmux-liveness} + the operator-custody queue. Read-only; zero network / API / SQL. bash 3.2-safe.
set -u

REPO_ROOT="$(git rev-parse --show-toplevel 2>/dev/null)" || { echo "status.sh: not in a git worktree" >&2; exit 2; }
cd "$REPO_ROOT" || exit 2

# Base lane census: the integrator (foundation) + the execution seat (executor). Adopters append their
# module lanes here (folder-equals-lane names), or export LANES to override.
LANES="${LANES:-foundation executor}"

hsha() { # short head sha for a lane
  local lane="$1"
  if [[ "$lane" == "foundation" ]]; then
    git rev-parse --short main 2>/dev/null || echo "(n/a)"
  else
    git rev-parse --short "refs/heads/module/${lane}" 2>/dev/null || echo "(n/a)"
  fi
}

last_outbox() { # newest outbox basename for a module lane
  local lane="$1"
  [[ "$lane" == "foundation" ]] && { echo "(hub — no outbox)"; return; }
  git ls-tree --name-only "module/${lane}:_orchestration/relay-outbox/${lane}/" 2>/dev/null \
    | grep -v '^\.gitkeep$' | sort | tail -1 | sed 's/^$/(none)/' | grep . || echo "(none)"
}

inbox_pending() { # coarse spine-inbox file count (NOT consume-aware)
  local lane="$1"
  git ls-tree --name-only "main:_orchestration/relay-inbox/${lane}/" 2>/dev/null \
    | grep -v '^\.gitkeep$' | grep -c . 2>/dev/null || echo 0
}

tmux_state() { # live / DOWN / DUP! by case-insensitive session name
  local lane="$1" n
  n="$(tmux list-panes -a -F '#{session_name}' 2>/dev/null | awk -v L="$lane" 'tolower($0)==tolower(L)' | grep -c . 2>/dev/null)"
  n="${n:-0}"
  case "$n" in 1) echo "live";; 0) echo "DOWN";; *) echo "DUP!($n)";; esac
}

echo "═══ STATUS $(date -u +%Y-%m-%dT%H:%M:%SZ) ═══ (live derive; snapshot = _orchestration/STATE-DIGEST.md)"
printf '%-12s %-9s %-6s %-8s %s\n' "LANE" "HEAD" "TMUX" "INBOX" "LAST-OUTBOX"
for lane in $LANES; do
  printf '%-12s %-9s %-6s %-8s %s\n' \
    "$lane" "$(hsha "$lane")" "$(tmux_state "$lane")" "$(inbox_pending "$lane")" "$(last_outbox "$lane")"
done

echo
echo "─── WAITING ON OPERATOR ───"
op_dir="_orchestration/relay-inbox/operator"
if [[ -d "$op_dir" ]]; then
  found=0
  # newest up to 5 operator-inbox files
  for f in $(ls -1t "$op_dir" 2>/dev/null | grep -v '^\.gitkeep$' | grep -v '^README' | head -5); do
    found=1
    pl="$(grep -m1 '^PAYLOAD:' "$op_dir/$f" 2>/dev/null | sed 's/^PAYLOAD:[[:space:]]*//')"
    printf '  • %s — %s\n' "$f" "${pl:-(see file)}"
  done
  [[ "$found" -eq 0 ]] && echo "  (no operator-inbox signals)"
else
  echo "  (operator inbox not present)"
fi
echo "  [known operator-custody queue — the project's apex go/no-go, credential, and publish items;"
echo "   refresh this list from dispatch/LATEST.md]:"
echo "    - {{OPERATOR_CUSTODY_ITEM}}   # e.g. an apex go/no-go, a credential/secret provision, a final publish"
