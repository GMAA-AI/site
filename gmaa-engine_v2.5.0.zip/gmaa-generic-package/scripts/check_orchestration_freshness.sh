#!/usr/bin/env bash
# scripts/check_orchestration_freshness.sh
#
# GENERICIZATION NOTE: unchanged mechanism; dated architect-relay narrative + the retired-STATE.md
# repoint story stripped. The live freshness surface is `.claude/session_state.json` (gitignored,
# local-only — meaningful in a working tree, not a clean checkout) + the decision-log.
#
# Asserts:
#   1. .claude/session_state.json mtime within STATE_BUDGET_DAYS (default 7)
#   2. _orchestration/decision-log.md mtime within DECISION_BUDGET_DAYS (default 14)
#   3. _orchestration/decision-log.md has at least 1 BOUND entry
# Output: "FRESH" on PASS (exit 0) or "STALE: <reason>" on FAIL (exit 1)

set -u
REPO_ROOT="$(git rev-parse --show-toplevel 2>/dev/null)"
[ -z "$REPO_ROOT" ] && REPO_ROOT="$(dirname "$0")/.."
cd "$REPO_ROOT" || exit 1

STATE_BUDGET_DAYS=${STATE_BUDGET_DAYS:-7}
DECISION_BUDGET_DAYS=${DECISION_BUDGET_DAYS:-14}

STATE=".claude/session_state.json"
DECISION="_orchestration/decision-log.md"

NOW=$(date +%s)
DAYS() { echo $(( ( NOW - $1 ) / 86400 )); }

# 1. session_state exists + fresh
if [ ! -f "$STATE" ]; then
  echo "STALE: $STATE missing"
  exit 1
fi
STATE_MTIME=$(stat -f %m "$STATE" 2>/dev/null || stat -c %Y "$STATE")
STATE_AGE_D=$(DAYS $STATE_MTIME)
if [ "$STATE_AGE_D" -gt "$STATE_BUDGET_DAYS" ]; then
  echo "STALE: $STATE age=${STATE_AGE_D}d > budget=${STATE_BUDGET_DAYS}d"
  exit 1
fi

# 2. decision-log.md exists + fresh
if [ ! -f "$DECISION" ]; then
  echo "STALE: $DECISION missing"
  exit 1
fi
DECISION_MTIME=$(stat -f %m "$DECISION" 2>/dev/null || stat -c %Y "$DECISION")
DECISION_AGE_D=$(DAYS $DECISION_MTIME)
if [ "$DECISION_AGE_D" -gt "$DECISION_BUDGET_DAYS" ]; then
  echo "STALE: $DECISION age=${DECISION_AGE_D}d > budget=${DECISION_BUDGET_DAYS}d"
  exit 1
fi

# 3. decision-log has at least 1 BOUND entry
BOUND_N=$(grep -c "Status:.*BOUND" "$DECISION" 2>/dev/null || echo 0)
if [ "$BOUND_N" -lt 1 ]; then
  echo "STALE: $DECISION has 0 BOUND entries"
  exit 1
fi

echo "FRESH: session_state age=${STATE_AGE_D}d decision-log age=${DECISION_AGE_D}d BOUND_entries=${BOUND_N}"
exit 0
